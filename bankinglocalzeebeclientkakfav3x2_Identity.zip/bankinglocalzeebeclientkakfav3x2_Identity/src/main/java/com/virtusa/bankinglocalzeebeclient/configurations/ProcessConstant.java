package com.virtusa.bankinglocalzeebeclient.configurations;

public class ProcessConstant {

    public static  final String BPMN_PROCESS_ID="Process_Loan";
    public static final String  TRAVEL_BPMN_PROCESS_ID="Process_Travel";
    public static final String ROLE_BPMN_PROCESS_ID="Process_Role";
}

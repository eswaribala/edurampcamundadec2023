package com.virtusa.bankingzeebeclient.configurations;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(HotelReservationFacade.class)
public class StreamConfig {

}

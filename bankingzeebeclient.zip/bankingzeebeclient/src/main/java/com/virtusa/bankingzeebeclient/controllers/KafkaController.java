package com.virtusa.bankingzeebeclient.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.bankingzeebeclient.configurations.HotelReservationFacade;



@RestController
public class KafkaController {
	@Autowired
	private HotelReservationFacade hotelReservationFacade;
	
	@GetMapping("/publish")
public boolean publishMessage(){  
		  
			
			  MessageChannel msgChannel=hotelReservationFacade.outputChannel();
			return  msgChannel.send(MessageBuilder .withPayload("Hi" ) .setHeader(MessageHeaders.CONTENT_TYPE,
			  MimeTypeUtils.APPLICATION_JSON) .build());
			 
		   
		   


}

}

package com.virtusa.bankinglocalzeebeclient.configurations;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;




@Configuration
public class KafkaConfiguration {
	@Autowired 
	private KafkaTemplate<Object, Object> template; 
	
	
	@JobWorker(type="", autoComplete = false)
	public void publishMessage(final JobClient jobClient, final ActivatedJob activatedJob) {
		
		  this.template.send("kafka-spring-demo", "Message from Job"); 
		
	}
	
	
}
